<?php
// Assuming you have a database connection established
// Replace with your database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cost_calculator";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $workCentre = $_POST['editWorkCentre'];
    $machine = $_POST['editMachine'];
    $newFC = $_POST['editFC'];
    $newVC = $_POST['editVC'];
    $newTC = $_POST['editTC'];

    // Perform a database update query to edit machine data based on Work Centre and Machine
    // Replace this with your actual database update query
    $query = "UPDATE machinedata SET FC = '$newFC', VC = '$newVC', TC = '$newTC' WHERE `Work Centre` = '$workCentre' AND `Machine` = '$machine'";

    $result = mysqli_query($conn, $query);

    if ($result) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Database edit failed"]);
    }
    $conn->close();
    
} else {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
}
?>
