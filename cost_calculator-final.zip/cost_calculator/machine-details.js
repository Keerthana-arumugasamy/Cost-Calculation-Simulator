document.addEventListener("DOMContentLoaded", function () {
    // Wait for the DOM to be fully loaded

    // Fetch data from the server
    fetch("get-machine-data.php")
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const tableBody = document.querySelector("#machine-data tbody");

            // Loop through the data and populate the table
            data.forEach(machine => {
                const row = tableBody.insertRow();
                row.innerHTML = `
                    <td>${machine['Work Centre']}</td>
                    <td>${machine['Machine']}</td>
                    <td>${machine['FC']}</td>
                    <td>${machine['VC']}</td>
                    <td>${machine['TC']}</td>
                `;
            });

            // Now that the data is loaded and table is populated, attach the event listeners
            const editButtons = documexnt.querySelectorAll(".edit-button");
            
            editButtons.forEach(button => {
                button.addEventListener("click", function (e) {
                    e.preventDefault();
                    const workCentre = this.getAttribute("data-work-centre");
                    const machine = this.getAttribute("data-machine");

                    // Call a function to handle the edit
                    editMachineData(workCentre, machine);

                });
            });


            // Now that the data is loaded and table is populated, attach the event listener
            const deleteForm = document.getElementById("deleteForm");
            deleteForm.addEventListener("submit", function (e) {
                e.preventDefault();
                
                const deleteWorkCentreInput = document.getElementById("deleteWorkCentre");
                const deleteMachineInput = document.getElementById("deleteMachine");
                
                const workCentre = deleteWorkCentreInput.value;
                const machine = deleteMachineInput.value;
                
                // Call a function to handle the deletion
                deleteMachineData(workCentre, machine);
            });
        })
        .catch(error => console.error("Error fetching data: " + error));
});
